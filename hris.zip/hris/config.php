<?php
ini_set('session.gc_maxlifetime', 12*60*60);
session_start();

$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$g_link = false;

$now = date('Y-m-d');

function connect(){
        global $g_link;

	if( $g_link ){
		return $g_link;
		}

	$g_link = mysql_connect( 'localhost', 'root', 'DsZ9fhcVLI9IPUfs') or die('Could not connect to server.' );
        mysql_select_db('payroll', $g_link) or die('Could not select database.');
        return $g_link;
	}

function clean(){
        global $g_link;
        if( $g_link != false ){
		mysql_close($g_link);
		}
        $g_link = false;
	}

function gEtFil($pst,$val){
	if($pst == $val){
		return 'selected';
		}
	else{
		return '';
		}
	}

function round_up($value, $precision = 0) {
	$value = explode(".",$value);
	$w = $value[0];
	$d = $value[1];
	$dlen = strlen($d);

	if($dlen==3){
		$d=$d . "111";
		}
	if($dlen==4){
		$d=$d . "11";
		}
	$num = $w . "." . $d;
	return round($num,2);
	}

function roundoff($amount,$id=2){
	$amount = round_up($amount,$id);
	return number_format($amount, $id, '.', ',');
	}

function roundoffNoComma($amount,$id=2){
	$amount = round_up($amount,$id);
	return number_format($amount, $id, '.', '');
	}

function ronc($amount,$id=2){
	$amount = round_up($amount,$id);
	return number_format($amount, $id, '.', '');
	}

function pad($input){
	return str_pad($input, 2, "0", STR_PAD_LEFT);
	}

function refresh(){
	echo "<script>";
	echo "self.location='index.php';";
	echo "</script>";
	}

function get_privileges($username,$menu){
	$select = "select count(*) as total from user_privileges where username = '" . $username . "' and menu='" . $menu . "'";
	$result = mysql_query($select, connect());
	$row = mysql_fetch_array($result,MYSQL_ASSOC);
	return $row['total'];
	}

function birthday($birthday){
	list($year,$month,$day) = explode("-",$birthday);
	$year_diff  = date("Y") - $year;
	$month_diff = date("m") - $month;
	$day_diff   = date("d") - $day;
	if ($day_diff < 0 || $month_diff < 0)
		$year_diff--;
	return $year_diff;
	}


function get_mycompany(){
	if ($_SESSION['company'] == '0'){
		$select = "select * from company where status = 'active'";
		}
	else{
		$select = "select * from company where status = 'active' and id = '" . $_SESSION['company'] . "' ";
		}
	return mysql_query($select, connect());
	}

function get_myposted(){
	if ($_SESSION['company'] == '0'){
		$select = "SELECT * FROM posted_summary GROUP BY posted_id order by posted_id desc";
		}
	else{
		$select = "SELECT * FROM posted_summary where `company_id` = '" . $_SESSION['company'] . "' GROUP BY posted_id order by posted_id desc";
		}
	return mysql_query($select, connect());
	}

function get_mybranch(){
	if ($_SESSION['company'] == '0'){
		$select = "select * from branch";
		}
	else{
		$select = "select * from company where status = 'active' and id = '" . $_SESSION['company'] . "' ";
		$result = mysql_query($select, connect());
		$row = mysql_fetch_array($result,MYSQL_ASSOC);
		$select = "select * from branch where company = '" . $row['name'] . "'";
		}
	return mysql_query($select, connect());
	}

function getword($codes){
	if($_SESSION['language']){
		require ('language/' . $_SESSION['language'] . '.php');
		}
	else{
		require ('language/english.php');
		}
	$word = $wtolang[trim($codes)];
	if($word == ""){
		return $codes;
		}
	else{
		return $word;
		}
	}

function sTr($str){
	$str = str_replace("'","&#39;",$str);
	$str = str_replace('"','&#34;',$str);
	$str = str_replace("\n","<br>",$str);
	return $str;
	}

$dd = '';
for ($x=1; $x < 32; $x++){
	$dd = $dd . "<option>" . pad($x) . "</option>";
	}

$yy = '';
for ($x=2016; $x < 2017; $x++){
	$yy = $yy . "<option>" . $x . "</option>";
	}

$mm = '';
for ($x=1; $x < 13; $x++){
	$mm = $mm . "<option>" . pad($x) . "</option>";
	}


$h = '';
for ($x=1; $x < 25; $x++){
	$h = $h . "<option>" . pad($x) . "</option>";
	}

$m = '';
for ($x=0; $x < 61; $x++){
	$m = $m . "<option>" . pad($x) . "</option>";
	}

$s = '';
for ($x=0; $x < 61; $x++){
	$s = $s . "<option>" . pad($x) . "</option>";
	}

$spacer  = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

$login=false;

################

$kez = "";
if($_SESSION['pay_id']){
	$kez1 = " pay_id = '" . $_SESSION['pay_id'] . "' and ";
	$kez11 = " (pay_id = '" . $_SESSION['pay_id'] . "' or pay_id_sub = '" . $_SESSION['pay_id'] . "') and ";
	}
if($_SESSION['company']){
	$kez2 = " company_id = '" . $_SESSION['company'] . "' and ";
	}

###################

if ($_GET['menu']){
	if ($_GET['menu'] != 19 && $_GET['menu'] != 10 && $_GET['menu'] != 11 && $_GET['menu'] != 29 && $_GET['menu'] != 25){
		if ($_SESSION['user']){
			if(($_GET['menu'] == 'myinfo' or $_GET['menu'] == 'leaveinfo' or $_GET['menu'] == '2') and $_SESSION['admin'] == false){

				}
			elseif (get_privileges($_SESSION['user'],$_GET['menu']) == 0){
				echo "<script>";
				echo "window.location='index.php?menu=19';";
				echo "</script>";
				}
			if ($_GET['pid']){
				if ($_SESSION['company'] != '0'){
					$select = "SELECT * FROM posted_summary where company_id = '" . $_SESSION['company'] . "' and posted_id = '" . $_GET['pid'] . "' GROUP BY posted_id";
					$result = mysql_query($select, connect());
					$row = mysql_fetch_array($result,MYSQL_ASSOC);
					if (empty($row['posted_id'])){
						echo "<script>";
						echo "window.location='index.php?menu=19';";
						echo "</script>";
						}
					}
				}
			}
		else{
			if($_GET['menu'] != 29){
				echo "<script>";
				echo "window.location='index.php?menu=10';";
				echo "</script>";
				}
			}
		}
	}
?>
