import time
import sys
import datetime
import MySQLdb

d = time.localtime(time.time())
date = time.strftime("%Y-%m-%d", d)
try:
	dt = sys.argv[1]
except:
	dt = date

date = dt
print date

dd = date.split("-")
ddd = datetime.date(int(dd[0]), int(dd[1]), int(dd[2]))
dname = ddd.strftime("%a")

mycon = MySQLdb.connect (host = "localhost", user = "root", passwd = "DsZ9fhcVLI9IPUfs", db = "payroll")
cursor = mycon.cursor()

select = """ select `em_id`, `salary`, `salary_based`, `shift_code`, `allowed_late`, `allowed_ot`, `allowed_ut`, `pay_id`, `company_id` from employee where status = 'active' """
cursor.execute(select)
em = cursor.fetchall()
for x in range(len(em)):
	select = """ select em_id from transaction where trxn_date = '%s' and em_id = '%s' """ % (date,em[x][0])
	cursor.execute(select)
	trxn = cursor.fetchall()
	
	if len(trxn)==0:
		if str(dname) == 'Sat' or str(dname) == 'Sun':
			statz = 'RESTDAY'
		else:
			statz = 'REGULAR'
		
		selectz = """ select `type`  from holiday_entry where `date` = '%s' limit 1 """ % str(date)
		cursor.execute(selectz)
		holiday = cursor.fetchall()
		if holiday:
			statz = holiday[0][0]

		insert = """ insert into `transaction` (
			`trxn_id` ,
			`trxn_date` ,
			`trxn_time_in` ,
			`trxn_time_out` ,
			`em_id` ,
			`salary_based` ,
			`salary` ,
			`ot` ,
			`holiday` ,
			`username` ,
			`datetime` ,
			`status`,
			`shift_code`,
			`allowed_late`,
			`allowed_ot`,
			`allowed_ut`,
			`pay_id`,
			`company_id`
			)
			values (
			null, 
			'%s', 
			'00:00:00', 
			'00:00:00', 
			'%s', 
			'%s', 
			'%s', 
			'0', 
			'', 
			'root', 
			now(), 
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s'
			) """ % (
			date,
			em[x][0],
			em[x][2],
			em[x][1],
			statz,
			em[x][3],
			em[x][4],
			em[x][5],
			em[x][6],
			em[x][7],
			em[x][8]
			)
		cursor.execute(insert)
		print x
	
