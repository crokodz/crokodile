<h3 class="wintitle"><blink><b>Warning...</b></blink></h3>
<form method="post">
<table width=100% border="0" cellpadding="4" cellspacing="0">
	<tr>
		<td align="left" ><b>user name and password is incorrect.</b> 3x incorrect login my required to input a confirmation code. more than 12x incorrect login, 
		administrator will automatically block your gateway ip. this may cause your entire network blocked in our system.</td>
	</tr>
</table>	
</form>