<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" id="facebook" class=" no_js">
<style>
.bod{
	font:bold 18pt Trebuchet MS; 
	}
</style>
<html>
<body>
<div class="bod">Your Browser is not reliable to our System Please use Firefox or Google Chrome</div>
<br>
<br>
<img src="chrome.jpg" style="width:200px"></img>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="firefox.jpg" style="width:200px"></img>
</body>
</html>

