<?php
$result = mysql_query("select *from users;", connect()); 

?>
<h3 class="wintitle"><blink><b>Warning To All...</b></blink></h3>
<form method="post">
<table width=100% border="0" cellpadding="4" cellspacing="0">
	<tr>
		<td align="left" >Please be informed that accessing unauthorized modules / errors are saved and sent to administration for immediate action.</td>
	</tr>
</table>	
</form>