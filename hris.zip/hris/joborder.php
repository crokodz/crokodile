<?php
$result = mysql_query("select *from users;", connect()); 

?>
<h3 class="wintitle">Jod Order</h3>
<form method="post">
<table width=100% border="0" cellpadding="4" cellspacing="0">
	<tr>
		<td></td>
	</tr>
</table>	
<table width=100% border="0" cellpadding="4" cellspacing="0" rules="all">
</table>
</form>