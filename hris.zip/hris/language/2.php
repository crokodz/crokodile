<?php
$wtolang = array(
"Username" => "Username",
"Password" => "Password"
);
?>